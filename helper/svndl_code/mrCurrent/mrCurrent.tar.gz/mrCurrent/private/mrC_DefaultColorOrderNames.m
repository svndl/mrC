function Names = mrC_DefaultColorOrderNames

Names = repmat( { 'Blue', 'LtGrn', 'Red', 'Cyan', 'Yellow', 'Magenta', 'Black', 'Orange' }, 1, 3 );

